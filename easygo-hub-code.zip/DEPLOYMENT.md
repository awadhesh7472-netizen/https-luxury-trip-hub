# EasyGo Hub — Deployment Guide

## One-click Vercel deploy
1. Push this repo to GitHub.
2. Go to https://vercel.com/new and import the repository.
3. Framework preset: **Vite**. Build command: `bun run build` (or `npm run build`). Output: `.output/public`.
4. Add environment variables from `.env.example` in **Settings → Environment Variables**.
5. Deploy. Custom domains can be added in **Settings → Domains** (SSL is automatic).

## Netlify
1. New site → Import from GitHub.
2. Build command: `bun run build`. Publish directory: `.output/public`.
3. Add env vars and click Deploy.

## Backend / DB
- This project uses **Lovable Cloud** (Supabase under the hood) for auth, DB, and storage. Enable it from the Lovable sidebar — no external account needed. Then run the migrations Lovable suggests for `bookings`, `users`, and `searches` tables.

## Razorpay
1. Create an account at https://razorpay.com.
2. Generate **Key ID** and **Key Secret** in Dashboard → Settings → API Keys.
3. Add them as `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` env vars.
4. Configure a webhook pointing to `/api/public/razorpay-webhook` and put the signing secret in `RAZORPAY_WEBHOOK_SECRET`.

## Firebase (optional alternative to Lovable Cloud)
1. Create a project at https://console.firebase.google.com.
2. Enable Authentication (Google, Email/Password, Phone).
3. Add Web App credentials to `.env` as `VITE_FIREBASE_*` keys.
4. Swap the auth helpers in `src/integrations/` to use Firebase SDK.