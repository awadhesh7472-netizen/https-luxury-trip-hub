import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Twitter, Youtube, Plane } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-[oklch(0.82_0.16_88/0.2)] bg-[oklch(0.1_0.005_60)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div className="size-8 rounded-lg gradient-gold flex items-center justify-center">
              <Plane className="size-4 text-[var(--primary-foreground)]" />
            </div>
            <span className="text-lg font-bold">EasyGo <span className="text-gradient-gold">Hub</span></span>
          </div>
          <p className="text-sm text-muted-foreground">Cheapest travel & lifestyle bookings, all in one luxury place.</p>
        </div>
        <FooterCol title="Services" links={[
          ["/flights","Flights"],["/trains","Trains"],["/buses","Buses"],
          ["/hotels","Hotels"],["/movies","Movies"],["/food","Food"]
        ]} />
        <FooterCol title="Company" links={[
          ["/about","About"],["/contact","Contact"],["/deals","Deals"],["/admin","Admin"]
        ]} />
        <div>
          <h4 className="text-sm font-semibold mb-3 text-gold">Follow Us</h4>
          <div className="flex gap-3">
            {[Facebook,Instagram,Twitter,Youtube].map((Icon,i)=>(
              <a key={i} href="#" className="size-9 rounded-full glass flex items-center justify-center hover:bg-gold hover:text-[var(--primary-foreground)] transition">
                <Icon className="size-4"/>
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-[oklch(0.82_0.16_88/0.15)] py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} EasyGo Hub. All rights reserved.
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: [string,string][] }) {
  return (
    <div>
      <h4 className="text-sm font-semibold mb-3 text-gold">{title}</h4>
      <ul className="space-y-2">
        {links.map(([to,label]) => (
          <li key={to}>
            <Link to={to} className="text-sm text-muted-foreground hover:text-gold transition-colors">{label}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}