import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Plane } from "lucide-react";

const nav = [
  { to: "/", label: "Home" },
  { to: "/flights", label: "Flights" },
  { to: "/trains", label: "Trains" },
  { to: "/buses", label: "Buses" },
  { to: "/hotels", label: "Hotels" },
  { to: "/movies", label: "Movies" },
  { to: "/food", label: "Food" },
  { to: "/deals", label: "Deals" },
];

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 glass-strong border-b border-[oklch(0.82_0.16_88/0.2)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="size-9 rounded-lg gradient-gold flex items-center justify-center shadow-gold">
            <Plane className="size-5 text-[var(--primary-foreground)]" />
          </div>
          <span className="text-xl font-bold tracking-tight">
            EasyGo <span className="text-gradient-gold">Hub</span>
          </span>
        </Link>
        <nav className="hidden lg:flex items-center gap-1">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-gold transition-colors"
              activeProps={{ className: "px-3 py-2 text-sm font-semibold text-gold" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="hidden lg:flex items-center gap-2">
          <Link to="/login" className="px-4 py-2 text-sm font-medium hover:text-gold transition-colors">
            Login
          </Link>
          <Link
            to="/login"
            className="px-4 py-2 rounded-lg gradient-gold text-[var(--primary-foreground)] text-sm font-semibold hover:opacity-90 transition shadow-gold"
          >
            Sign up
          </Link>
        </div>
        <button className="lg:hidden p-2" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>
      {open && (
        <div className="lg:hidden glass-strong border-t border-[oklch(0.82_0.16_88/0.2)] px-4 py-4 space-y-1 animate-fade-in">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              onClick={() => setOpen(false)}
              className="block px-3 py-2 rounded-md text-sm font-medium hover:bg-secondary hover:text-gold"
            >
              {n.label}
            </Link>
          ))}
          <Link to="/login" onClick={() => setOpen(false)} className="block px-3 py-2 rounded-md text-sm font-medium hover:bg-secondary">
            Login / Sign up
          </Link>
        </div>
      )}
    </header>
  );
}