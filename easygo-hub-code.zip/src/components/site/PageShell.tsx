import { Header } from "./Header";
import { Footer } from "./Footer";

export function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export function PageHero({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <section className="relative overflow-hidden border-b border-[oklch(0.82_0.16_88/0.15)]">
      <div className="absolute inset-0 opacity-30" style={{background:"radial-gradient(ellipse at top, oklch(0.82 0.16 88 / 0.25), transparent 60%)"}}/>
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        {eyebrow && <p className="text-xs uppercase tracking-[0.3em] text-gold mb-3">{eyebrow}</p>}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold">
          <span className="text-gradient-gold">{title}</span>
        </h1>
        {subtitle && <p className="mt-4 text-lg text-muted-foreground max-w-2xl">{subtitle}</p>}
      </div>
    </section>
  );
}