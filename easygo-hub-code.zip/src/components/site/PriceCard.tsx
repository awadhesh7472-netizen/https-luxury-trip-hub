import { motion } from "framer-motion";
import { ExternalLink, Sparkles } from "lucide-react";

export interface PriceResult {
  provider: string;
  price: number;
  meta?: string;
  badge?: string;
  link?: string;
}

export function PriceCard({ result, cheapest, index = 0 }: { result: PriceResult; cheapest?: boolean; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.05 }}
      className={`glass rounded-xl p-5 flex flex-col sm:flex-row sm:items-center gap-4 hover-lift ${cheapest ? "gold-border" : ""}`}
    >
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-lg">{result.provider}</h3>
          {cheapest && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider gradient-gold text-[var(--primary-foreground)] font-bold">
              <Sparkles className="size-3" /> Cheapest
            </span>
          )}
          {result.badge && !cheapest && (
            <span className="px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider bg-secondary text-muted-foreground">{result.badge}</span>
          )}
        </div>
        {result.meta && <p className="text-sm text-muted-foreground mt-1">{result.meta}</p>}
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className="text-2xl font-bold text-gradient-gold">₹{result.price.toLocaleString("en-IN")}</p>
        </div>
        <a
          href={result.link ?? "#"}
          target="_blank" rel="noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg gradient-gold text-[var(--primary-foreground)] text-sm font-semibold hover:opacity-90 transition shadow-gold whitespace-nowrap"
        >
          Book <ExternalLink className="size-3.5" />
        </a>
      </div>
    </motion.div>
  );
}