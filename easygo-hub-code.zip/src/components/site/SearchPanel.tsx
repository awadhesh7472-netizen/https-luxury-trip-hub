import { useState } from "react";
import { PriceCard, type PriceResult } from "./PriceCard";
import { mockResults } from "@/lib/mockSearch";
import { Search } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Field { name: string; label: string; type?: string; placeholder?: string; }

export function SearchPanel({
  service,
  fields,
  ctaLabel = "Search Cheapest",
}: { service: "flights"|"trains"|"buses"|"hotels"|"movies"|"food"; fields: Field[]; ctaLabel?: string }) {
  const [values, setValues] = useState<Record<string,string>>({});
  const [results, setResults] = useState<PriceResult[] | null>(null);
  const [loading, setLoading] = useState(false);

  function go(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setResults(mockResults(service, Object.values(values).join("|")));
      setLoading(false);
    }, 600);
  }

  return (
    <div>
      <form onSubmit={go} className="glass-strong rounded-2xl p-5 sm:p-6 shadow-elegant">
        <div className={`grid gap-4 ${fields.length >= 4 ? "md:grid-cols-2 lg:grid-cols-4" : "md:grid-cols-3"}`}>
          {fields.map((f) => (
            <label key={f.name} className="block">
              <span className="text-xs uppercase tracking-wider text-gold font-semibold">{f.label}</span>
              <input
                type={f.type ?? "text"}
                placeholder={f.placeholder}
                value={values[f.name] ?? ""}
                onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.value }))}
                className="mt-1.5 w-full bg-[oklch(0.1_0.005_60)] border border-[oklch(0.82_0.16_88/0.25)] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-gold focus:ring-2 focus:ring-[oklch(0.82_0.16_88/0.3)] transition"
              />
            </label>
          ))}
        </div>
        <button
          type="submit"
          disabled={loading}
          className="mt-5 w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg gradient-gold text-[var(--primary-foreground)] font-bold shadow-gold hover:opacity-90 transition disabled:opacity-60"
        >
          <Search className="size-4" />
          {loading ? "Searching across providers…" : ctaLabel}
        </button>
      </form>

      <AnimatePresence>
        {results && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 space-y-3"
          >
            <h2 className="text-xl font-semibold mb-2">
              <span className="text-gradient-gold">Best prices</span>{" "}
              <span className="text-muted-foreground text-sm">· sorted cheapest first</span>
            </h2>
            {results.map((r, i) => (
              <PriceCard key={r.provider} result={r} cheapest={i === 0} index={i} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}