import { PageShell, PageHero } from "./PageShell";
import { SearchPanel } from "./SearchPanel";

interface Field { name: string; label: string; type?: string; placeholder?: string; }

export function ServicePage({
  service, eyebrow, title, subtitle, fields,
}: { service: "flights"|"trains"|"buses"|"hotels"|"movies"|"food"; eyebrow: string; title: string; subtitle: string; fields: Field[] }) {
  return (
    <PageShell>
      <PageHero eyebrow={eyebrow} title={title} subtitle={subtitle} />
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
        <SearchPanel service={service} fields={fields} />
      </div>
    </PageShell>
  );
}