/**
 * EasyGo Hub — central API configuration.
 * Replace the stub fetchers with real provider calls when API keys are added.
 * All keys should be read on the server only (see .env.example).
 */
export const apiConfig = {
  amadeus: { base: "https://test.api.amadeus.com", env: "AMADEUS_API_KEY" },
  skyscanner: { base: "https://partners.api.skyscanner.net", env: "SKYSCANNER_API_KEY" },
  booking: { base: "https://distribution-xml.booking.com", env: "BOOKING_API_KEY" },
  redbus: { base: "https://api.redbus.com", env: "REDBUS_API_KEY" },
  abhibus: { base: "https://api.abhibus.com", env: "ABHIBUS_API_KEY" },
  tmdb: { base: "https://api.themoviedb.org/3", env: "TMDB_API_KEY" },
  razorpay: { base: "https://api.razorpay.com/v1", env: "RAZORPAY_KEY_SECRET" },
} as const;

export type ServiceKey = "flights" | "trains" | "buses" | "hotels" | "movies" | "food";