import type { PriceResult } from "@/components/site/PriceCard";

const providersByService: Record<string, string[]> = {
  flights: ["Amadeus", "Skyscanner", "MakeMyTrip", "Goibibo", "Cleartrip"],
  trains: ["IRCTC", "ConfirmTkt", "Trainman", "Ixigo"],
  buses: ["RedBus", "AbhiBus", "Paytm", "MakeMyTrip"],
  hotels: ["Booking.com", "Agoda", "MakeMyTrip", "OYO", "Goibibo"],
  movies: ["BookMyShow", "Paytm", "District"],
  food: ["Zomato", "Swiggy", "Domino's", "Pizza Hut"],
};

const baseRange: Record<string, [number, number]> = {
  flights: [2800, 9500],
  trains: [350, 2400],
  buses: [450, 1800],
  hotels: [1200, 8500],
  movies: [180, 520],
  food: [199, 899],
};

export function mockResults(service: keyof typeof providersByService, seed = ""): PriceResult[] {
  const provs = providersByService[service] ?? [];
  const [min, max] = baseRange[service] ?? [500, 3000];
  let s = (seed + service).split("").reduce((a, c) => a + c.charCodeAt(0), 7);
  const rand = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
  return provs
    .map((p) => ({
      provider: p,
      price: Math.round(min + rand() * (max - min)),
      meta: metaFor(service, rand),
    }))
    .sort((a, b) => a.price - b.price);
}

function metaFor(s: string, r: () => number) {
  switch (s) {
    case "flights": return `${(1 + Math.floor(r()*3))}h ${Math.floor(r()*60)}m · ${r()>0.5?"Non-stop":"1 stop"}`;
    case "trains": return `${r()>0.5?"Sleeper":"AC 3-Tier"} · ${Math.floor(8+r()*16)}h`;
    case "buses": return `${r()>0.5?"AC Sleeper":"Volvo Multi-Axle"} · ${Math.floor(6+r()*8)}h`;
    case "hotels": return `${(3+Math.floor(r()*3))}★ · Breakfast included`;
    case "movies": return `${r()>0.5?"IMAX":"Standard"} · Multiple shows`;
    case "food": return `Free delivery · ${(20+Math.floor(r()*25))} min`;
    default: return "";
  }
}