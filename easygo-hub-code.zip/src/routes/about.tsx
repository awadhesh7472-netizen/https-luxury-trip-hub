import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";
import { Sparkles, Globe2, ShieldCheck, Zap } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "About — EasyGo Hub" }] }),
  component: About,
});

const values = [
  { icon: Sparkles, title: "Luxury, accessible", desc: "Premium experience without premium prices." },
  { icon: Globe2, title: "Everything, one place", desc: "Flights, trains, hotels, movies, food — unified." },
  { icon: ShieldCheck, title: "Trusted providers", desc: "Only verified partners — Amadeus, Booking.com, IRCTC and more." },
  { icon: Zap, title: "Lightning fast", desc: "Sub-second comparisons across global APIs." },
];

function About() {
  return (
    <PageShell>
      <PageHero eyebrow="About us" title="Booking, reimagined." subtitle="EasyGo Hub is a luxury aggregator built for travelers who want the best price and the best experience — without compromise." />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid sm:grid-cols-2 gap-4">
          {values.map((v)=>(
            <div key={v.title} className="glass rounded-2xl p-6 hover-lift">
              <v.icon className="size-6 text-gold"/>
              <h3 className="mt-3 text-xl font-bold">{v.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{v.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 glass-strong rounded-3xl p-10 text-center gold-border">
          <h2 className="text-3xl font-bold"><span className="text-gradient-gold">Our mission</span></h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            To make every booking — from a weekend bus ride to a Maldives getaway — feel effortless, transparent, and indulgent.
          </p>
        </div>
      </div>
    </PageShell>
  );
}