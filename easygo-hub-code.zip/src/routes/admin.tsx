import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";
import { Users, CreditCard, ShoppingBag, BadgePercent, Image as ImageIcon, BarChart3 } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin Dashboard — EasyGo Hub" }] }),
  component: Admin,
});

const stats = [
  { label: "Users", value: "12,480", icon: Users, change: "+8.2%" },
  { label: "Bookings", value: "3,921", icon: ShoppingBag, change: "+12.1%" },
  { label: "Revenue", value: "48.7L", icon: CreditCard, change: "+5.6%" },
  { label: "Active offers", value: "27", icon: BadgePercent, change: "+3" },
];
const recent: string[][] = [
  ["#BK10293", "Aarav S.", "Flight DEL-GOI", "3,420", "Paid"],
  ["#BK10292", "Priya M.", "Hotel · Udaipur", "8,600", "Paid"],
  ["#BK10291", "Rohan K.", "Bus BLR-MAA", "890", "Pending"],
  ["#BK10290", "Neha T.", "Movie · IMAX", "720", "Paid"],
  ["#BK10289", "Karan B.", "Pizza · Dominos", "499", "Paid"],
];

function Admin() {
  return (
    <PageShell>
      <PageHero eyebrow="Internal" title="Admin dashboard." subtitle="Manage users, bookings, payments, banners and offers." />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <div key={s.label} className="glass rounded-2xl p-5 gold-border">
              <div className="flex items-center justify-between">
                <s.icon className="size-5 text-gold"/>
                <span className="text-xs text-gold font-semibold">{s.change}</span>
              </div>
              <p className="mt-3 text-2xl font-bold text-gradient-gold">{s.value}</p>
              <p className="text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 glass rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Recent bookings</h3>
              <button className="text-xs text-gold hover:underline">View all</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
                  <tr>{["ID","User","Service","Amount","Status"].map(h=>(<th key={h} className="text-left py-2 pr-4">{h}</th>))}</tr>
                </thead>
                <tbody>
                  {recent.map((r)=>(
                    <tr key={r[0]} className="border-b border-border/40">
                      {r.map((c,i)=>(
                        <td key={i} className="py-3 pr-4">
                          {i===4 ? (
                            <span className={`px-2 py-0.5 rounded-full text-xs ${c==="Paid"?"bg-[oklch(0.82_0.16_88/0.15)] text-gold":"bg-secondary text-muted-foreground"}`}>{c}</span>
                          ) : c}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="glass rounded-2xl p-6">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><BarChart3 className="size-5 text-gold"/>Analytics</h3>
            <div className="space-y-3">
              {[["Flights",80],["Hotels",62],["Buses",45],["Movies",30],["Food",55]].map(([k,v])=>(
                <div key={k as string}>
                  <div className="flex justify-between text-xs mb-1"><span>{k}</span><span className="text-gold font-semibold">{v}%</span></div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full gradient-gold" style={{width:`${v}%`}}/>
                  </div>
                </div>
              ))}
            </div>
            <button className="mt-6 w-full inline-flex items-center justify-center gap-2 py-2 rounded-lg glass gold-border text-sm font-medium hover:text-gold">
              <ImageIcon className="size-4"/> Manage banners
            </button>
          </div>
        </div>
      </div>
    </PageShell>
  );
}