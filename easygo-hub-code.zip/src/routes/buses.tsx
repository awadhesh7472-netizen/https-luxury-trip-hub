import { createFileRoute } from "@tanstack/react-router";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/buses")({
  head: () => ({ meta: [{ title: "Bus Booking — EasyGo Hub" }, { name: "description", content: "Cheapest buses across RedBus, AbhiBus and more." }] }),
  component: () => (
    <ServicePage
      service="buses"
      eyebrow="Bus booking"
      title="Roads, well taken."
      subtitle="RedBus, AbhiBus, Paytm, MakeMyTrip — instantly compared."
      fields={[
        { name: "from", label: "From", placeholder: "Bengaluru" },
        { name: "to", label: "To", placeholder: "Chennai" },
        { name: "date", label: "Date", type: "date" },
      ]}
    />
  ),
});