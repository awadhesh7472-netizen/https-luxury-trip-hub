import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";
import { Mail, Phone, MapPin } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact — EasyGo Hub" }] }),
  component: Contact,
});

function Contact() {
  return (
    <PageShell>
      <PageHero eyebrow="Contact" title="We're here to help." subtitle="Reach our concierge team — we answer within an hour." />
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-12 grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-strong rounded-2xl p-6">
          <form className="grid sm:grid-cols-2 gap-4" onSubmit={(e)=>e.preventDefault()}>
            <Field label="Name" placeholder="Your name"/>
            <Field label="Email" type="email" placeholder="you@email.com"/>
            <div className="sm:col-span-2"><Field label="Subject" placeholder="How can we help?"/></div>
            <div className="sm:col-span-2">
              <span className="text-xs uppercase tracking-wider text-gold font-semibold">Message</span>
              <textarea rows={5} className="mt-1.5 w-full bg-[oklch(0.1_0.005_60)] border border-[oklch(0.82_0.16_88/0.25)] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-gold"/>
            </div>
            <button className="sm:col-span-2 py-3 rounded-lg gradient-gold text-[var(--primary-foreground)] font-bold shadow-gold hover:opacity-90">Send message</button>
          </form>
        </div>
        <div className="space-y-3">
          {[
            {icon:Mail,label:"Email",value:"concierge@easygohub.com"},
            {icon:Phone,label:"Phone",value:"+91 98765 43210"},
            {icon:MapPin,label:"HQ",value:"Bengaluru, India"},
          ].map((c)=>(
            <div key={c.label} className="glass rounded-xl p-5 flex items-start gap-3">
              <c.icon className="size-5 text-gold mt-0.5"/>
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</p>
                <p className="font-semibold">{c.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PageShell>
  );
}

function Field({label,...rest}: {label:string} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-gold font-semibold">{label}</span>
      <input {...rest} className="mt-1.5 w-full bg-[oklch(0.1_0.005_60)] border border-[oklch(0.82_0.16_88/0.25)] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-gold"/>
    </label>
  );
}