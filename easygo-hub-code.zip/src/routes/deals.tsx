import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";
import { BadgePercent, Clock } from "lucide-react";

export const Route = createFileRoute("/deals")({
  head: () => ({ meta: [{ title: "Deals & Offers — EasyGo Hub" }] }),
  component: Deals,
});

const deals = [
  { tag: "FLAT 20%", title: "Domestic Flights", desc: "On all bookings above 3,000", code: "EASYFLY20", ends: "23h 12m" },
  { tag: "500 OFF", title: "Hotel Stays", desc: "Min booking 2,500", code: "STAY500", ends: "11h 04m" },
  { tag: "BUY 1 GET 1", title: "Movie Tickets", desc: "On weekends", code: "MOVIE2X", ends: "06h 33m" },
  { tag: "30% OFF", title: "Pizza Orders", desc: "Above 399", code: "PIZZA30", ends: "02h 47m" },
  { tag: "250 OFF", title: "Bus Tickets", desc: "First booking", code: "BUSNEW250", ends: "1d 04h" },
  { tag: "10% CASHBACK", title: "Train Bookings", desc: "Wallet credit", code: "TRAIN10CB", ends: "3d 12h" },
];

function Deals() {
  return (
    <PageShell>
      <PageHero eyebrow="Deals" title="Today's best offers." subtitle="Hand-picked coupons across all our services. Tap to copy and redeem." />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {deals.map((d) => (
          <div key={d.code} className="relative overflow-hidden glass rounded-2xl p-6 gold-border hover-lift">
            <BadgePercent className="absolute -right-4 -top-4 size-24 text-gold opacity-10"/>
            <span className="inline-block px-3 py-1 rounded-full text-xs font-bold gradient-gold text-[var(--primary-foreground)]">{d.tag}</span>
            <h3 className="mt-3 text-xl font-bold">{d.title}</h3>
            <p className="text-sm text-muted-foreground">{d.desc}</p>
            <div className="mt-4 flex items-center justify-between">
              <code className="px-3 py-1.5 rounded-md bg-secondary text-gold font-mono text-sm">{d.code}</code>
              <p className="flex items-center gap-1 text-xs text-muted-foreground"><Clock className="size-3.5"/> {d.ends}</p>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}