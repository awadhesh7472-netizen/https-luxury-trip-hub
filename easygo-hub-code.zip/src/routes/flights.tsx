import { createFileRoute } from "@tanstack/react-router";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/flights")({
  head: () => ({ meta: [{ title: "Flight Booking — EasyGo Hub" }, { name: "description", content: "Compare cheapest flights across Amadeus, Skyscanner and more." }] }),
  component: () => (
    <ServicePage
      service="flights"
      eyebrow="Flight booking"
      title="Fly for less."
      subtitle="One search across Amadeus, Skyscanner, MakeMyTrip, Goibibo and Cleartrip."
      fields={[
        { name: "from", label: "From", placeholder: "Delhi (DEL)" },
        { name: "to", label: "To", placeholder: "Goa (GOI)" },
        { name: "date", label: "Departure", type: "date" },
        { name: "pax", label: "Passengers", type: "number", placeholder: "1" },
      ]}
    />
  ),
});