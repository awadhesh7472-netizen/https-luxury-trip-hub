import { createFileRoute } from "@tanstack/react-router";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/food")({
  head: () => ({ meta: [{ title: "Food & Pizza Ordering — EasyGo Hub" }] }),
  component: () => (
    <ServicePage
      service="food"
      eyebrow="Food & pizza"
      title="Hungry? Save more."
      subtitle="Zomato, Swiggy, Domino's, Pizza Hut — best deal wins."
      fields={[
        { name: "city", label: "City", placeholder: "Pune" },
        { name: "cuisine", label: "Cuisine", placeholder: "Pizza" },
      ]}
    />
  ),
});