import { createFileRoute } from "@tanstack/react-router";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/hotels")({
  head: () => ({ meta: [{ title: "Hotel Booking — EasyGo Hub" }, { name: "description", content: "Compare hotels across Booking.com, Agoda, MakeMyTrip and OYO." }] }),
  component: () => (
    <ServicePage
      service="hotels"
      eyebrow="Hotel booking"
      title="Stay in style."
      subtitle="Booking.com, Agoda, MakeMyTrip, OYO, Goibibo — best rate, every time."
      fields={[
        { name: "city", label: "Destination", placeholder: "Udaipur" },
        { name: "checkin", label: "Check in", type: "date" },
        { name: "checkout", label: "Check out", type: "date" },
        { name: "guests", label: "Guests", type: "number", placeholder: "2" },
      ]}
    />
  ),
});