import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/site/PageShell";
import { SearchPanel } from "@/components/site/SearchPanel";
import { motion } from "framer-motion";
import { Plane, Train, Bus, Hotel, Film, Pizza, Clock, Star, ArrowRight, BadgePercent } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "EasyGo Hub — Cheapest Flights, Trains, Hotels & More" },
      { name: "description", content: "Compare the cheapest prices across booking sites for flights, trains, buses, hotels, movies, and food." },
    ],
  }),
  component: Index,
});

const services = [
  { key: "flights", icon: Plane, label: "Flights", to: "/flights" },
  { key: "trains", icon: Train, label: "Trains", to: "/trains" },
  { key: "buses", icon: Bus, label: "Buses", to: "/buses" },
  { key: "hotels", icon: Hotel, label: "Hotels", to: "/hotels" },
  { key: "movies", icon: Film, label: "Movies", to: "/movies" },
  { key: "food", icon: Pizza, label: "Food", to: "/food" },
] as const;

const destinations = [
  { name: "Goa", price: 2899, img: "🏖️" },
  { name: "Dubai", price: 14999, img: "🌆" },
  { name: "Manali", price: 3499, img: "🏔️" },
  { name: "Bali", price: 22999, img: "🌴" },
  { name: "Jaipur", price: 1899, img: "🕌" },
  { name: "Maldives", price: 34999, img: "🏝️" },
];

const deals = [
  { tag: "FLAT 20%", title: "Domestic Flights", code: "EASYFLY20", ends: "23h 12m" },
  { tag: "₹500 OFF", title: "Hotel Bookings", code: "STAY500", ends: "11h 04m" },
  { tag: "BUY 1 GET 1", title: "Movie Tickets", code: "MOVIE2X", ends: "06h 33m" },
];

const testimonials = [
  { name: "Aarav S.", quote: "Saved ₹2,400 on a Delhi–Goa flight in minutes. Stunning interface.", rating: 5 },
  { name: "Priya M.", quote: "Compared 5 hotel sites in one search. Booked the cheapest, no fuss.", rating: 5 },
  { name: "Rohan K.", quote: "The deals page paid for my weekend trip. Couldn't recommend more.", rating: 5 },
];

function Index() {
  const [tab, setTab] = useState<(typeof services)[number]["key"]>("flights");
  const fields = fieldsFor(tab);
  return (
    <PageShell>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-40" style={{background:"radial-gradient(ellipse at 50% 0%, oklch(0.82 0.16 88 / 0.35), transparent 55%)"}}/>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 sm:pt-24 pb-12">
          <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:0.6}} className="text-center max-w-3xl mx-auto">
            <p className="text-xs uppercase tracking-[0.4em] text-gold mb-4">Luxury booking, everyday prices</p>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold leading-tight">
              The <span className="text-gradient-gold">cheapest</span> way<br/>to book anything.
            </h1>
            <p className="mt-5 text-lg text-muted-foreground">
              We scan top providers in seconds — flights, trains, hotels, movies, food — and show you the lowest price first.
            </p>
          </motion.div>

          <motion.div initial={{opacity:0,y:24}} animate={{opacity:1,y:0}} transition={{duration:0.6,delay:0.15}} className="mt-10">
            <div className="flex flex-wrap justify-center gap-2 mb-4">
              {services.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setTab(s.key)}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition ${
                    tab === s.key ? "gradient-gold text-[var(--primary-foreground)] shadow-gold" : "glass hover:text-gold"
                  }`}
                >
                  <s.icon className="size-4" /> {s.label}
                </button>
              ))}
            </div>
            <SearchPanel service={tab} fields={fields} />
          </motion.div>
        </div>
      </section>

      {/* SERVICES GRID */}
      <Section title="All services">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {services.map((s) => (
            <Link key={s.key} to={s.to} className="glass rounded-xl p-5 text-center hover-lift group">
              <s.icon className="size-7 mx-auto text-gold group-hover:scale-110 transition" />
              <p className="mt-3 text-sm font-semibold">{s.label}</p>
            </Link>
          ))}
        </div>
      </Section>

      {/* TRENDING DEALS */}
      <Section title="Trending deals" eyebrow="Limited time">
        <div className="grid md:grid-cols-3 gap-4">
          {deals.map((d, i) => (
            <motion.div
              key={d.code}
              initial={{opacity:0,y:12}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*0.1}}
              className="relative overflow-hidden rounded-2xl gold-border p-6 glass hover-lift"
            >
              <BadgePercent className="absolute -right-4 -top-4 size-24 text-gold opacity-10"/>
              <span className="inline-block px-3 py-1 rounded-full text-xs font-bold gradient-gold text-[var(--primary-foreground)]">{d.tag}</span>
              <h3 className="mt-3 text-xl font-bold">{d.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">Code: <span className="text-gold font-mono">{d.code}</span></p>
              <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground"><Clock className="size-3.5"/> Ends in {d.ends}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* DESTINATIONS */}
      <Section title="Popular destinations" eyebrow="Wanderlust">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {destinations.map((d) => (
            <div key={d.name} className="glass rounded-xl p-5 text-center hover-lift">
              <div className="text-4xl">{d.img}</div>
              <p className="mt-2 font-semibold">{d.name}</p>
              <p className="text-xs text-muted-foreground">from <span className="text-gold font-bold">₹{d.price.toLocaleString("en-IN")}</span></p>
            </div>
          ))}
        </div>
      </Section>

      {/* TESTIMONIALS */}
      <Section title="Loved by travelers" eyebrow="Testimonials">
        <div className="grid md:grid-cols-3 gap-4">
          {testimonials.map((t) => (
            <div key={t.name} className="glass rounded-2xl p-6">
              <div className="flex gap-0.5 mb-3">
                {Array.from({length:t.rating}).map((_,i)=>(<Star key={i} className="size-4 fill-[var(--gold)] text-[var(--gold)]"/>))}
              </div>
              <p className="text-sm text-muted-foreground">"{t.quote}"</p>
              <p className="mt-4 text-sm font-semibold text-gold">— {t.name}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-20">
        <div className="rounded-3xl gold-border glass-strong p-10 sm:p-14 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20" style={{background:"radial-gradient(ellipse at center, oklch(0.82 0.16 88 / 0.5), transparent 60%)"}}/>
          <div className="relative">
            <h2 className="text-3xl sm:text-4xl font-bold"><span className="text-gradient-gold">Ready to save?</span></h2>
            <p className="mt-3 text-muted-foreground">Join thousands booking smarter, cheaper, faster.</p>
            <Link to="/login" className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-lg gradient-gold text-[var(--primary-foreground)] font-bold shadow-gold hover:opacity-90 transition">
              Get started free <ArrowRight className="size-4"/>
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}

function Section({ title, eyebrow, children }: { title: string; eyebrow?: string; children: React.ReactNode }) {
  return (
    <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-20">
      {eyebrow && <p className="text-xs uppercase tracking-[0.3em] text-gold mb-2">{eyebrow}</p>}
      <h2 className="text-3xl font-bold mb-6">{title}</h2>
      {children}
    </section>
  );
}

function fieldsFor(s: string) {
  switch (s) {
    case "flights":
    case "trains":
    case "buses":
      return [
        { name: "from", label: "From", placeholder: "Delhi" },
        { name: "to", label: "To", placeholder: "Goa" },
        { name: "date", label: "Date", type: "date" },
        { name: "pax", label: "Passengers", type: "number", placeholder: "1" },
      ];
    case "hotels":
      return [
        { name: "city", label: "City", placeholder: "Mumbai" },
        { name: "checkin", label: "Check in", type: "date" },
        { name: "checkout", label: "Check out", type: "date" },
        { name: "guests", label: "Guests", type: "number", placeholder: "2" },
      ];
    case "movies":
      return [
        { name: "city", label: "City", placeholder: "Bengaluru" },
        { name: "movie", label: "Movie", placeholder: "Title" },
        { name: "date", label: "Date", type: "date" },
      ];
    case "food":
      return [
        { name: "city", label: "City", placeholder: "Pune" },
        { name: "cuisine", label: "Cuisine", placeholder: "Pizza" },
      ];
    default:
      return [];
  }
}
