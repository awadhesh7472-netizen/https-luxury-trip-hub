import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/site/PageShell";
import { Mail, Smartphone, Plane } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Login or Register — EasyGo Hub" }] }),
  component: Login,
});

function Login() {
  const [tab, setTab] = useState<"login"|"register">("login");
  return (
    <PageShell>
      <div className="mx-auto max-w-md px-4 py-16">
        <div className="glass-strong rounded-2xl p-8 shadow-elegant">
          <div className="flex items-center gap-2 justify-center mb-6">
            <div className="size-10 rounded-lg gradient-gold flex items-center justify-center shadow-gold">
              <Plane className="size-5 text-[var(--primary-foreground)]"/>
            </div>
            <span className="text-xl font-bold">EasyGo <span className="text-gradient-gold">Hub</span></span>
          </div>
          <div className="grid grid-cols-2 mb-6 rounded-lg bg-secondary p-1">
            {(["login","register"] as const).map((t)=>(
              <button key={t} onClick={()=>setTab(t)} className={`py-2 text-sm font-semibold rounded-md transition ${tab===t?"gradient-gold text-[var(--primary-foreground)]":"text-muted-foreground"}`}>
                {t==="login"?"Login":"Register"}
              </button>
            ))}
          </div>
          <form className="space-y-3" onSubmit={(e)=>e.preventDefault()}>
            {tab==="register" && <Field label="Full name" placeholder="Aarav Sharma" />}
            <Field label="Email" type="email" placeholder="you@email.com"/>
            <Field label="Password" type="password" placeholder="••••••••"/>
            <button className="w-full py-2.5 rounded-lg gradient-gold text-[var(--primary-foreground)] font-bold shadow-gold hover:opacity-90 transition">
              {tab==="login"?"Login":"Create account"}
            </button>
          </form>
          <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="flex-1 h-px bg-border"/> or continue with <div className="flex-1 h-px bg-border"/>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <Social icon={<GoogleIcon/>} label="Google"/>
            <Social icon={<Mail className="size-4"/>} label="Email"/>
            <Social icon={<Smartphone className="size-4"/>} label="OTP"/>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

function Field({label,...rest}: {label:string} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-gold font-semibold">{label}</span>
      <input {...rest} className="mt-1.5 w-full bg-[oklch(0.1_0.005_60)] border border-[oklch(0.82_0.16_88/0.25)] rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-gold focus:ring-2 focus:ring-[oklch(0.82_0.16_88/0.3)]"/>
    </label>
  );
}
function Social({icon,label}:{icon:React.ReactNode;label:string}) {
  return (
    <button type="button" className="flex flex-col items-center gap-1 p-3 rounded-lg glass hover-lift text-xs font-medium">
      {icon}{label}
    </button>
  );
}
function GoogleIcon() {
  return <svg className="size-4" viewBox="0 0 24 24"><path fill="currentColor" d="M21.35 11.1H12v3.2h5.35c-.23 1.6-1.7 4.7-5.35 4.7a6 6 0 1 1 0-12 5.4 5.4 0 0 1 3.8 1.5l2.6-2.5A9 9 0 1 0 12 21c5.18 0 8.6-3.65 8.6-8.8 0-.58-.07-1.04-.15-1.5z"/></svg>;
}