import { createFileRoute } from "@tanstack/react-router";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/movies")({
  head: () => ({ meta: [{ title: "Movie Tickets — EasyGo Hub" }] }),
  component: () => (
    <ServicePage
      service="movies"
      eyebrow="Movie tickets"
      title="Lights. Camera. Saved."
      subtitle="BookMyShow, Paytm, District — show times and seats, compared."
      fields={[
        { name: "city", label: "City", placeholder: "Hyderabad" },
        { name: "movie", label: "Movie", placeholder: "Title" },
        { name: "date", label: "Date", type: "date" },
      ]}
    />
  ),
});