import { createFileRoute } from "@tanstack/react-router";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/trains")({
  head: () => ({ meta: [{ title: "Train Booking — EasyGo Hub" }, { name: "description", content: "Search and book the cheapest train tickets across India." }] }),
  component: () => (
    <ServicePage
      service="trains"
      eyebrow="Train booking"
      title="Ride the rails."
      subtitle="IRCTC, ConfirmTkt, Trainman and Ixigo — compared in one place."
      fields={[
        { name: "from", label: "From", placeholder: "Mumbai CST" },
        { name: "to", label: "To", placeholder: "Pune Jn" },
        { name: "date", label: "Date", type: "date" },
        { name: "class", label: "Class", placeholder: "AC 3-Tier" },
      ]}
    />
  ),
});